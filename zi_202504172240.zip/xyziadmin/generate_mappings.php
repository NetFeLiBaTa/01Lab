<?php
// xyziadmin/generate_mappings.php - 生成簡繁映射表
// 版本: 1.59
// 確認時間: 2025-04-16 15:30:00 PDT

require 'database.php';

// 設置執行環境
ini_set('max_execution_time', 300);
ini_set('memory_limit', '256M');
ini_set('default_charset', 'UTF-8');
mb_internal_encoding('UTF-8');

$db = Database::getInstance();
$output = '';
$log_file = '../logs/generate.log';
$mappings_dir = '../xyzimappings/';

// 檢查目錄可寫
if (!is_writable($mappings_dir)) {
    $error = "Error: Directory $mappings_dir is not writable\n";
    file_put_contents($log_file, $error, FILE_APPEND);
    echo $error;
    exit;
}

// 確保目錄存在
if (!is_dir($mappings_dir)) {
    if (!mkdir($mappings_dir, 0755, true)) {
        $error = "Error: Failed to create directory $mappings_dir\n";
        file_put_contents($log_file, $error, FILE_APPEND);
        echo $error;
        exit;
    }
}

// 清理舊檔案
foreach (glob("$mappings_dir/xyzi_simplified_to_traditional.json") as $file) {
    if (unlink($file)) {
        file_put_contents($log_file, "Removed file $file at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
    } else {
        file_put_contents($log_file, "Failed to remove file $file at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
    }
}

try {
    $start_time = microtime(true);
    $sql = "SELECT simplified_zi, traditional_zi FROM sczi_dictionary WHERE simplified_zi IS NOT NULL AND traditional_zi IS NOT NULL";
    $stmt = $db->prepare($sql);
    if ($stmt === false) {
        $error = "SQL prepare failed: " . implode(', ', $db->errorInfo()) . "\n";
        file_put_contents($log_file, $error, FILE_APPEND);
        echo $error;
        exit;
    }
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $mappings = [];
    $count = 0;
    foreach ($results as $row) {
        $simp = $row['simplified_zi'];
        $trad = $row['traditional_zi'];
        if (!preg_match('/^[\p{Han}]+$/u', $simp)) {
            continue;
        }
        // 分割 traditional_zi，可能包含多個繁體字
        $trad_chars = array_filter(array_map('trim', explode('、', $trad)));
        if (empty($trad_chars)) {
            continue;
        }
        // 驗證每個繁體字
        $valid_trad_chars = [];
        foreach ($trad_chars as $char) {
            if (preg_match('/^[\p{Han}]+$/u', $char)) {
                $valid_trad_chars[] = $char;
            }
        }
        if (!empty($valid_trad_chars)) {
            $mappings[$simp] = $valid_trad_chars;
            $count += count($valid_trad_chars);
        }
    }

    $file_path = "$mappings_dir/xyzi_simplified_to_traditional.json";
    $json_data = json_encode($mappings, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json_data === false) {
        throw new Exception("Failed to encode JSON");
    }
    if (file_put_contents($file_path, $json_data) === false) {
        throw new Exception("Failed to write $file_path");
    }
    if (!file_exists($file_path)) {
        throw new Exception("File $file_path was not created");
    }
    chmod($file_path, 0644);

    $output .= "Generated xyzi_simplified_to_traditional.json ($count mappings)\n";
    file_put_contents($log_file, "Generated $file_path ($count mappings) at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

    $end_time = microtime(true);
    $duration = round($end_time - $start_time, 2);
    file_put_contents($log_file, "Processed mappings ($count records) in {$duration}s at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
} catch (Exception $e) {
    $error = "Error generating mappings: " . $e->getMessage() . " at " . date('Y-m-d H:i:s') . "\n";
    $output .= $error;
    file_put_contents($log_file, $error, FILE_APPEND);
}

echo $output;
?>
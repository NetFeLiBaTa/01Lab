<?php
// xyziadmin/generate_strokes_sync.php - 同步生成筆畫索引
// 版本: 1.59
// 確認時間: 2025-04-17

require 'database.php';
require 'config.php';

// 設置執行環境
ini_set('max_execution_time', 600);
ini_set('memory_limit', '512M');
ini_set('default_charset', 'UTF-8');
mb_internal_encoding('UTF-8');

$db = Database::getInstance();
$output = '';
$log_file = '../logs/generate.log';
$debug_file = '../logs/debug.log';
$strokes_dir = rtrim('../xyzistrokes', '/'); // 移除結尾斜線
$enable_rare_chars = true;

// 確保 radical_map 存在
if (!isset($config['radical_map']) || !is_array($config['radical_map'])) {
    $config['radical_map'] = [
        '金' => ['金', '弋'],
        '木' => ['竹', '米', '巾', '木', '文'],
        '水' => ['气', '水', '雨'],
        '火' => ['火', '心'],
        '土' => ['土', '田', '石', '玉']
    ];
    file_put_contents($log_file, "Warning: radical_map missing, using default at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
}

// 檢查目錄可寫
if (!is_writable($strokes_dir)) {
    $error = "Error: Directory $strokes_dir is not writable\n";
    file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
    $output .= $error;
}

// 確保目錄存在
if (!is_dir($strokes_dir)) {
    if (!mkdir($strokes_dir, 0755, true)) {
        $error = "Error: Failed to create directory $strokes_dir\n";
        file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
        $output .= $error;
    }
}

// 清理舊檔案
foreach (glob("$strokes_dir/xyzi_stroke_*.html") as $file) {
    if (unlink($file)) {
        file_put_contents($log_file, "Removed file $file at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
    } else {
        file_put_contents($log_file, "Failed to remove file $file at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
    }
}

function renderCharItem($char, $wuxing) {
    $wuxing_class = in_array($wuxing, ['金', '木', '水', '火', '土']) ? 'wuxing-' . mb_strtolower($wuxing, 'UTF-8') : '';
    return '<span class="char-item ' . $wuxing_class . '" data-char="' . htmlspecialchars($char) . '">' . htmlspecialchars($char) . '</span>';
}

function generateStrokeHtml($stroke, $results, $is_rare = false) {
    global $config, $log_file;
    $wuxing_groups = [];
    $stroke_wuxing_groups = [];
    $common_chars = 0;
    $rare_chars = 0;
    $invalid_chars = 0;
    $rare_chars_displayed = 0;
    $seen_chars = [];

    foreach ($results as $row) {
        $char = $row['traditional'];
        if (array_key_exists($char, $seen_chars)) {
            continue;
        }
        $seen_chars[$char] = true;

        $stroke_count = $row['stroke_count'];
        $wuxing = trim($row['wuxing']);
        $radical = trim($row['radical']);

        if (!preg_match('/^[\p{Han}]+$/u', $char)) {
            $invalid_chars++;
            continue;
        }

        $unicode = mb_ord($char, 'UTF-8');
        if ($unicode >= 0x4E00 && $unicode <= 0x9FFF) {
            $common_chars++;
        } elseif ($unicode >= 0x20000 && $unicode <= 0x2FFFF) {
            $rare_chars++;
            if (!$is_rare) {
                continue;
            }
            $rare_chars_displayed++;
        } else {
            $invalid_chars++;
            continue;
        }

        $assigned_wuxing = '其他';
        if ($wuxing && in_array($wuxing, ['金', '木', '水', '火', '土'])) {
            $assigned_wuxing = $wuxing;
        } elseif ($radical && isset($config['radical_map']) && is_array($config['radical_map'])) {
            foreach ($config['radical_map'] as $wx => $radicals) {
                if (is_array($radicals) && in_array($radical, $radicals)) {
                    $assigned_wuxing = $wx;
                    break;
                }
            }
        }

        if ($stroke === '30+' && $stroke_count >= 30) {
            $key = $stroke_count . '_' . $assigned_wuxing;
            $stroke_wuxing_groups[$key][] = [$char, $assigned_wuxing];
        } else {
            $wuxing_groups[$assigned_wuxing][] = [$char, $assigned_wuxing];
        }

        // 每處理 500 個字符清理一次內存
        if (count($seen_chars) % 500 === 0) {
            gc_collect_cycles();
        }
    }

    if ($common_chars == 0 && ($is_rare ? $rare_chars : 0) == 0) {
        file_put_contents($log_file, "No valid data for stroke $stroke (is_rare=$is_rare) at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
        return null;
    }

    $html = '<div class="stroke-results">';
    $html .= '<p class="stroke-count">筆畫 ' . ($stroke === '30+' ? '30以上' : $stroke) . '：共 ' . ($common_chars + ($is_rare ? $rare_chars : 0)) . ' 個漢字</p>';
    $html .= '<p class="char-stats">漢字統計：常用字 ' . $common_chars . ' 個，罕見字 ' . $rare_chars . ' 個（顯示 ' . ($is_rare ? $rare_chars_displayed : 0) . ' 個），無效字 ' . $invalid_chars . ' 個</p>';

    if ($stroke === '30+') {
        ksort($stroke_wuxing_groups);
        foreach ($stroke_wuxing_groups as $key => $chars) {
            [$stroke_num, $wuxing] = explode('_', $key);
            $html .= '<div class="stroke-wuxing-group">';
            $html .= '<h3>' . $stroke_num . ' 畫 ' . htmlspecialchars($wuxing) . '（' . count($chars) . '個）</h3>';
            $html .= '<div class="char-list">';
            foreach ($chars as [$char, $assigned_wuxing]) {
                $html .= renderCharItem($char, $assigned_wuxing);
            }
            $html .= '</div>';
            $html .= '</div>';
        }
    } else {
        $order = ['金', '木', '水', '火', '土', '其他'];
        foreach ($order as $wuxing) {
            if (empty($wuxing_groups[$wuxing])) {
                continue;
            }
            $chars = $wuxing_groups[$wuxing];
            $html .= '<div class="wuxing-group">';
            $html .= '<h3>' . htmlspecialchars($wuxing) . '（' . count($chars) . '個）</h3>';
            $html .= '<div class="char-list">';
            foreach ($chars as [$char, $assigned_wuxing]) {
                $html .= renderCharItem($char, $assigned_wuxing);
            }
            $html .= '</div>';
            $html .= '</div>';
        }
    }
    $html .= '</div>';

    return $html;
}

$start_total = microtime(true); // 記錄總開始時間
$strokes = range(1, 30);
$strokes[] = '30+';
$total_files = 0;

foreach ($strokes as $stroke) {
    try {
        $start_time = microtime(true);
        $sql = $stroke === '30+'
            ? "SELECT DISTINCT k.traditional, k.stroke_count, COALESCE(s.wuxing, '') AS wuxing, COALESCE(k.radical, '') AS radical FROM kangxi_dictionary k LEFT JOIN sczi_dictionary s ON k.traditional = s.traditional_zi WHERE k.stroke_count >= 30 AND k.stroke_count <= 60"
            : "SELECT DISTINCT k.traditional, k.stroke_count, COALESCE(s.wuxing, '') AS wuxing, COALESCE(k.radical, '') AS radical FROM kangxi_dictionary k LEFT JOIN sczi_dictionary s ON k.traditional = s.traditional_zi WHERE k.stroke_count = ?";
        $stmt = $db->prepare($sql);
        if ($stmt === false) {
            $error = "SQL prepare failed for stroke $stroke: " . implode(', ', $db->errorInfo()) . "\n";
            file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
            file_put_contents($debug_file, $error, FILE_APPEND | LOCK_EX);
            $output .= $error;
            continue;
        }
        if ($stroke !== '30+') {
            $stmt->execute([(int)$stroke]);
        } else {
            $stmt->execute();
        }
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $result_count = count($results);
        file_put_contents($log_file, "Stroke $stroke: fetched $result_count records at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);

        if (empty($results)) {
            $output .= "No data for stroke $stroke\n";
            file_put_contents($log_file, "No data for stroke $stroke at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
            file_put_contents($debug_file, "No data for stroke $stroke at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
            continue;
        }

        // 生成普通頁面（僅常用字）
        $html = generateStrokeHtml($stroke, $results, false);
        if ($html !== null) {
            $file_path = "$strokes_dir/xyzi_stroke_$stroke.html";
            if (file_put_contents($file_path, $html) === false) {
                throw new Exception("Failed to write $file_path");
            }
            if (!file_exists($file_path)) {
                throw new Exception("File $file_path was not created");
            }
            chmod($file_path, 0644);
            $output .= "Generated xyzi_stroke_$stroke.html\n";
            $total_files++;
            file_put_contents($log_file, "Generated $file_path at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
            file_put_contents($debug_file, "Generated $file_path at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
        }

        // 生成罕見字頁面（包含所有字）
        if ($enable_rare_chars) {
            $rare_html = generateStrokeHtml($stroke, $results, true);
            if ($rare_html !== null) {
                $rare_file_path = "$strokes_dir/xyzi_stroke_{$stroke}_rare.html";
                if (file_put_contents($rare_file_path, $rare_html) === false) {
                    throw new Exception("Failed to write $rare_file_path");
                }
                if (!file_exists($rare_file_path)) {
                    throw new Exception("File $rare_file_path was not created");
                }
                chmod($rare_file_path, 0644);
                $output .= "Generated xyzi_stroke_{$stroke}_rare.html\n";
                $total_files++;
                file_put_contents($log_file, "Generated $rare_file_path at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
                file_put_contents($debug_file, "Generated $rare_file_path at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
            }
        }

        // 清理記憶體
        unset($results, $stmt, $html, $rare_html);
        gc_collect_cycles();
        $end_time = microtime(true);
        $duration = round($end_time - $start_time, 2);
        file_put_contents($log_file, "Processed stroke $stroke ($result_count records, $total_files files) in {$duration}s at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
        file_put_contents($log_file, "Memory usage for stroke $stroke: " . (memory_get_usage() / 1024 / 1024) . " MB at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
    } catch (Exception $e) {
        $error = "Error generating stroke $stroke: " . $e->getMessage() . " at " . date('Y-m-d H:i:s') . "\n";
        $output .= $error;
        file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
        file_put_contents($debug_file, $error, FILE_APPEND | LOCK_EX);
        continue;
    }
}

if ($total_files > 0) {
    $output .= "Total files generated: $total_files\n";
    file_put_contents($log_file, "Total files generated: $total_files at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
} else {
    $output .= "No files generated\n";
    file_put_contents($log_file, "No files generated at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
}

$end_total = microtime(true);
$total_duration = round($end_total - $start_total, 2);
file_put_contents($log_file, "Total generation time: {$total_duration}s at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
file_put_contents($debug_file, "Final output for generate_strokes_sync at " . date('Y-m-d H:i:s') . ":\n$output\n", FILE_APPEND | LOCK_EX);
?>
<!DOCTYPE html>
<html lang="zh-HK">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>筆畫索引生成結果</title>
    <style>
        body {
            font-family: 'Noto Sans SC', Arial, sans-serif;
            max-width: 1200px;
            margin: 20px auto;
            padding: 15px;
            background: #f5faff;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }
        pre {
            background: #f0f8ff;
            padding: 15px;
            border-radius: 6px;
            overflow-x: auto;
            font-size: 14px;
            color: #2c3e50;
        }
        .return-btn {
            display: block;
            margin: 20px auto;
            padding: 12px 24px;
            background: #6b7280;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            text-align: center;
            text-decoration: none;
        }
        .return-btn:hover {
            background: #4b5563;
        }
    </style>
</head>
<body>
    <h2>筆畫索引生成結果</h2>
    <pre><?php echo htmlspecialchars($output); ?></pre>
    <a href="manage.php" class="return-btn">返回管理面板</a>
</body>
</html>
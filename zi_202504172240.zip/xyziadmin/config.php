<?php
// xyziadmin/config.php - 系統配置
// 版本: 1.5
// 確認時間: 2025-05-01

return [
    'db' => [
        'host' => 'localhost',
        'database' => 'cyber_xtech',
        'user' => 'root',
        'password' => '398efb5bab1316fc',
    ],
    'wuxing_colors' => [
        '金' => '#f1c40f',
        '木' => '#2ECC71',
        '水' => '#000000',
        '火' => '#E74C3C',
        '土' => '#8B4513',
    ],
    'radical_map' => [
        '金' => ['金', '弋'],
        '木' => ['竹', '米', '巾', '木', '文'],
        '水' => ['气', '水', '雨'],
        '火' => ['火', '心'],
        '土' => ['土', '田', '石', '玉']
    ],
    'enable_rare_chars' => true,
];
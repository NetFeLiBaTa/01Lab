<?php
// xyziadmin/manage.php - 管理面板
// 版本: 1.59
// 確認時間: 2025-04-17

ini_set('default_charset', 'UTF-8');
mb_internal_encoding('UTF-8');
header('Content-Type: text/html; charset=UTF-8');

ini_set('display_errors', 'Off');
ini_set('log_errors', 'On');
ini_set('error_log', '../logs/php_errors.log');
?>
<!DOCTYPE html>
<html lang="zh-HK">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理面板</title>
    <link rel="icon" href="data:,">
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        .word-query-container {
            max-width: 1200px;
            width: 96%;
            margin: 20px auto;
            font-family: 'Noto Sans SC', Arial, sans-serif;
            background: linear-gradient(135deg, #f5faff 0%, #f6fff6 100%);
            padding: 15px;
            border-radius: 12px;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
            font-size: 95%;
            animation: fadeIn 0.5s;
        }
        .word-query-container h2 {
            text-align: center;
            color: #2c3e50;
            font-size: 28px;
            margin-bottom: 20px;
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
        }
        .btn-group {
            display: flex;
            justify-content: center;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        .btn {
            padding: 12px 24px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s, transform 0.2s, box-shadow 0.3s;
        }
        .btn:hover {
            background: #45a049;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(76, 175, 80, 0.3);
        }
        .btn:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        .clear-btn {
            padding: 12px 24px;
            background: #e74c3c;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s, transform 0.2s;
            margin: 10px auto;
            display: block;
        }
        .clear-btn:hover {
            background: #c0392b;
            transform: scale(1.05);
        }
        .message {
            margin: 10px 0;
            font-size: 14px;
            color: #2c3e50;
            background: #f0f8ff;
            padding: 10px;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            text-align: left;
            max-height: 300px;
            overflow-y: auto;
        }
        .message div {
            margin-bottom: 5px;
            word-break: break-all;
        }
        .message div:last-child {
            margin-bottom: 0;
        }
        .error {
            margin: 10px 0;
            font-size: 14px;
            color: #ff4757;
            background: #ffe6e6;
            padding: 10px;
            border-radius: 6px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.08);
            text-align: left;
            display: none;
        }
        .error.visible {
            display: block;
        }
        .log-view {
            background: #ffffff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            max-height: 300px;
            overflow-y: auto;
            font-size: 12px;
            color: #34495e;
            line-height: 1.5;
            margin-bottom: 20px;
        }
        .log-view::-webkit-scrollbar {
            width: 5px;
        }
        .log-view::-webkit-scrollbar-thumb {
            background: #4CAF50;
            border-radius: 2px;
        }
        .loader {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 3px solid #f0f8ff;
            border-top: 3px solid #4CAF50;
            border-radius: 50%;
            width: 36px;
            height: 36px;
            animation: spin 1s linear infinite;
            display: none;
        }
        .return-btn {
            display: block;
            margin: 20px auto;
            padding: 12px 24px;
            background: #6b7280;
            color: white;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s, transform 0.2s;
            text-align: center;
            text-decoration: none;
        }
        .return-btn:hover {
            background: #4b5563;
            transform: scale(1.05);
        }
        @keyframes spin {
            0% { transform: translate(-50%, -50%) rotate(0deg); }
            100% { transform: translate(-50%, -50%) rotate(360deg); }
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @media (max-width: 768px) {
            .word-query-container {
                padding: 10px;
                margin: 10px auto;
            }
            .word-query-container h2 {
                font-size: 24px;
            }
            .btn-group {
                flex-direction: column;
                gap: 10px;
            }
            .btn, .clear-btn {
                width: 100%;
                max-width: 320px;
                padding: 10px;
                font-size: 13px;
            }
            .message, .error {
                font-size: 12px;
            }
            .log-view {
                font-size: 11px;
            }
            .return-btn {
                padding: 10px 20px;
                font-size: 13px;
            }
        }
        @media (max-width: 480px) {
            .word-query-container h2 {
                font-size: 20px;
            }
            .btn, .clear-btn {
                padding: 8px;
                font-size: 12px;
            }
            .log-view {
                max-height: 200px;
            }
        }
    </style>
</head>
<body>
    <div class="word-query-container">
        <h2>管理面板</h2>
        <div class="btn-group">
            <button class="btn" data-action="generate_chars">生成字典</button>
            <button class="btn" data-action="generate_mappings">生成映射表</button>
            <form action="generate_strokes_sync.php" method="post" style="display: inline;">
                <button type="submit" class="btn">生成筆畫索引（同步）</button>
            </form>
        </div>
        <button class="clear-btn" id="clearBtn">清空訊息</button>
        <div id="message" class="message"></div>
        <div id="errorMsg" class="error"></div>
        <div class="loader"></div>
        <div class="log-view" id="logView"></div>
        <a href="../xyzi.html" class="return-btn">返回主頁</a>
    </div>
    <script>
        // 內嵌 JavaScript，實現生成功能和日誌預覽
        (function() {
            const buttons = document.querySelectorAll('.btn[data-action]');
            const clearBtn = document.getElementById('clearBtn');
            const message = document.getElementById('message');
            const errorMsg = document.getElementById('errorMsg');
            const loader = document.querySelector('.loader');
            const logView = document.getElementById('logView');
            let isProcessing = false;
            let messageHistory = [];

            function debounce(func, wait) {
                let timeout;
                return function executedFunction(...args) {
                    const later = () => {
                        clearTimeout(timeout);
                        func(...args);
                    };
                    clearTimeout(timeout);
                    timeout = setTimeout(later, wait);
                };
            }

            function fetchLog() {
                fetch('../logs/generate.log')
                    .then(res => {
                        if (!res.ok) throw new Error('無法讀取日誌');
                        return res.text();
                    })
                    .then(text => {
                        const lines = text.split('\n').filter(line => line.trim()).slice(-10);
                        logView.innerHTML = lines.map(line => `<div>${line}</div>`).join('');
                        logView.scrollTop = logView.scrollHeight;
                    })
                    .catch(err => {
                        console.error('日誌讀取失敗:', err);
                    });
            }

            function appendMessage(text, isError = false) {
                if (isError) {
                    errorMsg.textContent = text;
                    errorMsg.className = 'error visible';
                } else {
                    messageHistory.push(text);
                    message.innerHTML = messageHistory.map(line => `<div>${line}</div>`).join('');
                    message.scrollTop = message.scrollHeight;
                }
            }

            function clearMessages() {
                messageHistory = [];
                message.innerHTML = '';
                errorMsg.textContent = '';
                errorMsg.className = 'error';
            }

            function executeAction(action) {
                if (isProcessing) return;
                isProcessing = true;
                buttons.forEach(btn => btn.disabled = true);
                loader.style.display = 'block';
                errorMsg.className = 'error';

                const controller = new AbortController();
                const timeoutId = setTimeout(() => {
                    controller.abort();
                    appendMessage(`[${new Date().toLocaleString()}] ${action.replace('generate_', '')} 失敗：請求超時`, true);
                }, 30000);

                const startTime = Date.now();
                fetch(action + '.php', {
                    method: 'POST',
                    signal: controller.signal,
                    headers: {
                        'Accept': 'text/plain'
                    }
                })
                    .then(res => {
                        clearTimeout(timeoutId);
                        if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
                        return res.text();
                    })
                    .then(data => {
                        const lines = data.trim().split('\n').filter(line => line.trim());
                        if (lines.length === 0) {
                            appendMessage(`[${new Date().toLocaleString()}] ${action.replace('generate_', '')} 完成：無數據返回`, true);
                        } else {
                            lines.forEach(line => {
                                appendMessage(`[${new Date().toLocaleString()}] ${action.replace('generate_', '')} 完成：${line}`);
                            });
                        }
                        fetchLog();
                    })
                    .catch(err => {
                        clearTimeout(timeoutId);
                        appendMessage(`[${new Date().toLocaleString()}] ${action.replace('generate_', '')} 失敗：${err.message}`, true);
                    })
                    .finally(() => {
                        isProcessing = false;
                        buttons.forEach(btn => btn.disabled = false);
                        loader.style.display = 'none';
                        const duration = (Date.now() - startTime) / 1000;
                        console.log(`Action ${action} completed in ${duration}s`);
                    });
            }

            function init() {
                buttons.forEach(btn => {
                    btn.addEventListener('click', debounce(() => {
                        const action = btn.dataset.action;
                        if (action) executeAction(action);
                    }, 300));
                });
                clearBtn.addEventListener('click', debounce(clearMessages, 300));
                fetchLog();
                console.log('管理面板初始化完成');
            }

            document.addEventListener('DOMContentLoaded', init);
        })();
    </script>
</body>
</html>
<?php
// xyziadmin/generate_chars.php - 生成字典
// 版本: 1.59
// 確認時間: 2025-04-17

require 'database.php';
require 'config.php';

// 設置執行環境
ini_set('max_execution_time', 600);
ini_set('memory_limit', '512M');
ini_set('default_charset', 'UTF-8');
mb_internal_encoding('UTF-8');
// 禁用輸出緩衝
ini_set('output_buffering', 'Off');

// 設置響應頭，防止緩衝並確保響應關閉
header('Content-Type: text/plain; charset=UTF-8');
header('X-Accel-Buffering: no'); // 禁用 Nginx 緩衝（若適用）
header('Connection: close');

// 檢查目錄可寫
$chars_dir = rtrim('../xyzichars', '/'); // 移除結尾斜線
$log_file = '../logs/generate.log';
$debug_file = '../logs/debug.log';
if (!is_writable($chars_dir)) {
    $error = "Error: Directory $chars_dir is not writable\n";
    file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
    echo $error;
    exit;
}

// 確保目錄存在
if (!is_dir($chars_dir)) {
    if (!mkdir($chars_dir, 0755, true)) {
        $error = "Error: Failed to create directory $chars_dir\n";
        file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
        echo $error;
        exit;
    }
}

// 清理無效檔案
foreach (glob("$chars_dir/xyzi_char_*.html") as $file) {
    if (unlink($file)) {
        file_put_contents($log_file, "Removed file $file at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
    } else {
        file_put_contents($log_file, "Failed to remove file $file at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
    }
}

// 確保 radical_map 存在
if (!isset($config['radical_map']) || !is_array($config['radical_map'])) {
    $config['radical_map'] = [
        '金' => ['金', '弋'],
        '木' => ['竹', '米', '巾', '木', '文'],
        '水' => ['气', '水', '雨'],
        '火' => ['火', '心'],
        '土' => ['土', '田', '石', '玉']
    ];
    file_put_contents($log_file, "Warning: radical_map missing, using default at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
}

$db = Database::getInstance();
$output = '';
$strokes = range(1, 30);
$strokes[] = '30+';
$total_generated = 0;

$start_total = microtime(true); // 記錄總開始時間

foreach ($strokes as $stroke) {
    try {
        $start_time = microtime(true);
        $sql = $stroke === '30+'
            ? "SELECT s.simplified_zi, s.traditional_zi, s.pinyin, s.stroke_count AS stroke_simplified, COALESCE(s.wuxing, '') AS wuxing, COALESCE(s.basicmean, '') AS basicmean, COALESCE(s.detailmean, '') AS detailmean, COALESCE(s.miyu, '') AS miyu, COALESCE(s.baike, '') AS baike, k.stroke_count AS stroke_kangxi, COALESCE(k.radical, '') AS radical_kangxi, COALESCE(k.dictionary_entry, '') AS dictionary_entry FROM sczi_dictionary s LEFT JOIN kangxi_dictionary k ON s.traditional_zi = k.traditional WHERE k.stroke_count >= 30 AND k.stroke_count <= 60 AND k.stroke_count IS NOT NULL"
            : "SELECT s.simplified_zi, s.traditional_zi, s.pinyin, s.stroke_count AS stroke_simplified, COALESCE(s.wuxing, '') AS wuxing, COALESCE(s.basicmean, '') AS basicmean, COALESCE(s.detailmean, '') AS detailmean, COALESCE(s.miyu, '') AS miyu, COALESCE(s.baike, '') AS baike, k.stroke_count AS stroke_kangxi, COALESCE(k.radical, '') AS radical_kangxi, COALESCE(k.dictionary_entry, '') AS dictionary_entry FROM sczi_dictionary s LEFT JOIN kangxi_dictionary k ON s.traditional_zi = k.traditional WHERE k.stroke_count = ? AND k.stroke_count IS NOT NULL ORDER BY RAND() LIMIT 10";
        $stmt = $db->prepare($sql);
        if ($stmt === false) {
            $error = "SQL prepare failed for stroke $stroke: " . implode(', ', $db->errorInfo()) . "\n";
            file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
            $output .= $error;
            continue;
        }
        if ($stroke !== '30+') {
            $stmt->execute([(int)$stroke]);
        } else {
            $stmt->execute();
        }
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $result_count = count($results);
        file_put_contents($log_file, "Stroke $stroke: fetched $result_count records at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);

        if (empty($results)) {
            $output .= "No data for stroke $stroke\n";
            file_put_contents($log_file, "No data for stroke $stroke at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
            continue;
        }

        $generated_chars = 0;
        foreach ($results as $row) {
            $chars = array_filter(array_map('trim', explode('、', $row['traditional_zi'])));
            if (empty($chars)) {
                $hex_char = bin2hex($row['traditional_zi']);
                file_put_contents($log_file, "Skipped invalid char {$row['traditional_zi']} (hex: $hex_char) for stroke $stroke at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
                continue;
            }

            foreach ($chars as $char) {
                if (!preg_match('/^[\p{Han}]+$/u', $char)) {
                    $hex_char = bin2hex($char);
                    file_put_contents($log_file, "Skipped invalid char $char (hex: $hex_char) for stroke $stroke at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
                    continue;
                }

                try {
                    $row['traditional_zi'] = $char; // 單個繁體字
                    $html = generateCharHtml($row);
                    $hex_char = strtoupper(bin2hex($char));
                    $file_path = "$chars_dir/xyzi_char_{$hex_char}.html";
                    file_put_contents($debug_file, "Preparing to generate char $char (hex: $hex_char, path: $file_path) for stroke $stroke at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);

                    if (!preg_match('/^[0-9A-F]+$/i', $hex_char)) {
                        throw new Exception("Invalid hex $hex_char for char $char");
                    }

                    if (file_put_contents($file_path, $html) === false) {
                        throw new Exception("Failed to write $file_path");
                    }

                    if (!file_exists($file_path)) {
                        throw new Exception("File $file_path was not created");
                    }
                    $file_size = filesize($file_path);
                    if ($file_size < 100) {
                        throw new Exception("File $file_path is too small ($file_size bytes)");
                    }

                    chmod($file_path, 0644);
                    $output .= "Generated xyzi_char_{$hex_char}.html (hex: $hex_char, path: $file_path)\n";
                    $generated_chars++;
                    $total_generated++;
                    file_put_contents($debug_file, "Successfully generated $file_path ($file_size bytes) at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
                    file_put_contents($log_file, "Generated $file_path at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
                } catch (Exception $e) {
                    $error = "Error generating char $char (hex: " . bin2hex($char) . ") for stroke $stroke: " . $e->getMessage() . " at " . date('Y-m-d H:i:s') . "\n";
                    file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
                    file_put_contents($debug_file, $error, FILE_APPEND | LOCK_EX);
                }
            }
        }

        $end_time = microtime(true);
        $duration = round($end_time - $start_time, 2);
        file_put_contents($log_file, "Generated xyzi_char for stroke $stroke ($generated_chars of $result_count chars) in {$duration}s at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
    } catch (Exception $e) {
        $error = "Error generating chars for stroke $stroke: " . $e->getMessage() . " at " . date('Y-m-d H:i:s') . "\n";
        $output .= $error;
        file_put_contents($log_file, $error, FILE_APPEND | LOCK_EX);
        file_put_contents($debug_file, $error, FILE_APPEND | LOCK_EX);
    }
}

$output .= "Total generated: $total_generated files\n";
file_put_contents($log_file, "Total generated: $total_generated files at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);
file_put_contents($debug_file, "Final output for generate_chars at " . date('Y-m-d H:i:s') . ":\n$output\n", FILE_APPEND | LOCK_EX);

$end_total = microtime(true);
$total_duration = round($end_total - $start_total, 2);
file_put_contents($log_file, "Total generation time: {$total_duration}s at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND | LOCK_EX);

function generateCharHtml($row) {
    global $config;
    $wuxing = is_string($row['wuxing']) ? trim($row['wuxing']) : '';
    $radical = is_string($row['radical_kangxi']) ? trim($row['radical_kangxi']) : '';
    $assigned_wuxing = $wuxing && in_array($wuxing, ['金', '木', '水', '火', '土']) ? $wuxing : '無';
    if (!$wuxing && $radical) {
        foreach ($config['radical_map'] as $wx => $radicals) {
            if (is_array($radicals) && in_array($radical, $radicals)) {
                $assigned_wuxing = $wx;
                break;
            }
        }
    }

    $template = file_get_contents('templates/char.html');
    $replace = [
        '{{char}}' => htmlspecialchars($row['traditional_zi']),
        '{{traditional}}' => htmlspecialchars($row['traditional_zi']),
        '{{simplified}}' => htmlspecialchars($row['simplified_zi'] ?: $row['traditional_zi']),
        '{{stroke_kangxi}}' => htmlspecialchars($row['stroke_kangxi'] ?: '無'),
        '{{stroke_simplified}}' => htmlspecialchars($row['stroke_simplified'] ?: '無'),
        '{{wuxing}}' => htmlspecialchars($assigned_wuxing),
        '{{pinyin}}' => htmlspecialchars($row['pinyin'] ?: '無'),
        '{{radical_kangxi}}' => htmlspecialchars($row['radical_kangxi'] ?: '無'),
        '{{dictionary_entry}}' => htmlspecialchars($row['dictionary_entry'] ?: '無'),
        '{{basicmean}}' => htmlspecialchars($row['basicmean'] ?: '無'),
        '{{detailmean}}' => htmlspecialchars($row['detailmean'] ?: '無'),
        '{{miyu}}' => htmlspecialchars($row['miyu'] ?: '無'),
        '{{baike}}' => htmlspecialchars($row['baike'] ?: '無')
    ];
    return str_replace(array_keys($replace), array_values($replace), $template);
}

echo $output;
?>
<?php
// xyziadmin/update_template.php - 更新模板與程式碼
// 版本: 1.5
// 確認時間: 2025-05-01

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        copy('../xyzi_styles.css', '../xyzi_styles.css.bak');
        copy('../xyzi_scripts.js', '../xyzi_scripts.js.bak');
        copy('templates/char.html', 'templates/char.html.bak');
        
        file_put_contents('templates/char.html', $_POST['char_template']);
        file_put_contents('../xyzi_styles.css', $_POST['css']);
        file_put_contents('../xyzi_scripts.js', $_POST['js']);
        
        echo '更新成功';
    } catch (Exception $e) {
        echo '更新失敗：' . $e->getMessage();
    }
}
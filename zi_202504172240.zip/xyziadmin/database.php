<?php
// xyziadmin/database.php - 資料庫連線
// 版本: 1.5
// 確認時間: 2025-05-01

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $config = require 'config.php';
        $dsn = "mysql:host={$config['db']['host']};dbname={$config['db']['database']};charset=utf8mb4";
        try {
            $this->pdo = new PDO($dsn, $config['db']['user'], $config['db']['password'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]);
        } catch (PDOException $e) {
            throw new Exception('資料庫連線失敗：' . $e->getMessage());
        }

        $tables = ['sczi_dictionary', 'kangxi_dictionary'];
        foreach ($tables as $table) {
            $result = $this->pdo->query("SHOW TABLES LIKE '$table'")->fetchAll();
            if (empty($result)) {
                throw new Exception("資料庫缺少表：$table");
            }
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance->pdo;
    }
}
<?php
// xyziadmin/fortune.php - 數吉計算（動態）
// 版本: 1.5
// 確認時間: 2025-05-01

function calculateNumberFortune($num) {
    $num = (string)$num;
    if (!preg_match('/^\d+$/', $num)) {
        return ['result1' => ['text' => '無效數字', 'color' => '#000000'], 'result2' => ['text' => '無效數字', 'color' => '#000000']];
    }

    $TestNum = [
        1 => "繁榮發達，信用得固，萬人仰望，可獲成功。（吉）",
        2 => "動搖不安，一榮一枯，一盛一衰，勞而無功。（凶）",
        // ... 保持現有邏輯，省略完整列表
        81 => "最吉之數，還本歸元，能得繁榮，發達成功。（吉）"
    ];

    $ColorNum = [
        1 => "（吉）",
        2 => "（吉帶凶）",
        3 => "（凶）"
    ];
    $ColorMap = [
        "（吉）" => "#FF0033",
        "（吉帶凶）" => "#000000",
        "（凶）" => "#336600"
    ];

    $sum = array_sum(str_split($num));
    while ($sum > 81) $sum -= 80;
    if ($sum == 0) $sum = 80;
    $result1_text = $TestNum[$sum] ?? '未知結果';
    $result1_color = "#000000";
    foreach ($ColorNum as $key => $color) {
        if (strpos($result1_text, $color) !== false) {
            $result1_color = $ColorMap[$color];
            break;
        }
    }

    $num2 = (int)$num % 80;
    if ($num2 == 0) $num2 = 80;
    $result2_text = $TestNum[$num2] ?? '未知結果';
    $result2_color = "#000000";
    foreach ($ColorNum as $key => $color) {
        if (strpos($result2_text, $color) !== false) {
            $result2_color = $ColorMap[$color];
            break;
        }
    }

    return [
        'result1' => ['text' => $result1_text, 'color' => $result1_color],
        'result2' => ['text' => $result2_text, 'color' => $result2_color]
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['strokes'])) {
    header('Content-Type: application/json');
    $strokes = (int)$_POST['strokes'];
    $result = calculateNumberFortune($strokes);
    $html = "<div class='number-results'>";
    $html .= "<p class='stroke-total'>康熙筆畫總和：$strokes</p>";
    $html .= "<p class='fortune-result' style='color: " . htmlspecialchars($result['result1']['color']) . ";'>數吉結果1：" . htmlspecialchars($result['result1']['text']) . "</p>";
    $html .= "<p class='fortune-result' style='color: " . htmlspecialchars($result['result2']['color']) . ";'>數吉結果2：" . htmlspecialchars($result['result2']['text']) . "</p>";
    $html .= "</div>";
    echo json_encode(['success' => true, 'data' => $html]);
}
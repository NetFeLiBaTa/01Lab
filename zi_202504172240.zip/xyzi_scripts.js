/* xyzi_scripts.js - 漢字查詢客戶端腳本 */
/* 版本: 1.59 */
/* 確認時間: 2025-04-16 */

(function () {
    const wordInput = document.getElementById('wordInput');
    const searchBtn = document.getElementById('searchBtn');
    const errorMsg = document.getElementById('errorMsg');
    const loader = document.querySelector('.loader');
    const strokeLinks = document.querySelector('.stroke-links');
    const showRareChars = document.getElementById('showRareChars');
    const strokeResults = document.getElementById('strokeResults');
    const numberResults = document.getElementById('numberResults');
    const wordNav = document.getElementById('wordNav');
    const result = document.getElementById('result');
    let mappings = {};

    // 五行顏色映射
    const wuxingColors = {
        '金': '#FFD700', // 金色
        '木': '#008000', // 綠色
        '水': '#0000FF', // 藍色
        '火': '#FF0000', // 紅色
        '土': '#8B4513', // 棕色
        '其他': '#808080' // 灰色
    };

    // 載入簡繁映射表
    function loadMappings() {
        return fetch('xyzimappings/xyzi_simplified_to_traditional.json')
            .then(res => {
                if (!res.ok) throw new Error('無法載入映射表');
                return res.json();
            })
            .then(data => {
                mappings = data;
            })
            .catch(err => {
                console.error('映射表載入失敗:', err);
                errorMsg.textContent = '無法載入簡繁映射表';
                errorMsg.style.opacity = 1;
            });
    }

    // 顯示多繁體字選擇介面
    function showTradSelection(chars, callback) {
        const modal = document.createElement('div');
        modal.className = 'trad-selection-modal';
        modal.style.cssText = `
            position: fixed; top: 0; left: 0; width: 100%; height: 100%; 
            background: rgba(0,0,0,0.5); display: flex; justify-content: center; 
            align-items: center; z-index: 1000;
        `;
        
        const container = document.createElement('div');
        container.style.cssText = `
            background: #fff; padding: 20px; border-radius: 12px; 
            max-width: 90%; max-height: 80%; overflow-y: auto; 
            box-shadow: 0 4px 16px rgba(0,0,0,0.2); text-align: center;
        `;
        
        const title = document.createElement('h3');
        title.textContent = '請選擇繁體字';
        title.style.cssText = 'margin-bottom: 20px; color: #2c3e50;';
        container.appendChild(title);

        const charGroups = document.createElement('div');
        charGroups.style.cssText = 'display: flex; flex-direction: column; gap: 15px;';

        let selectedChars = new Array(chars.length).fill(null);
        chars.forEach((charInfo, index) => {
            const group = document.createElement('div');
            group.style.cssText = 'display: flex; align-items: center; gap: 10px;';
            
            const charLabel = document.createElement('span');
            charLabel.textContent = `字 ${index + 1}: ${charInfo.char}`;
            charLabel.style.cssText = 'font-size: 16px; color: #2c3e50; min-width: 100px;';
            group.appendChild(charLabel);

            const btnGroup = document.createElement('div');
            btnGroup.style.cssText = 'display: flex; gap: 10px; flex-wrap: wrap;';
            
            charInfo.trads.forEach(trad => {
                const btn = document.createElement('button');
                btn.textContent = trad;
                btn.style.cssText = `
                    padding: 10px 20px; font-size: 16px; border: 2px solid #d0d7de; 
                    border-radius: 8px; background: #f0f8ff; color: #2c3e50; cursor: pointer; 
                    min-width: 60px; transition: all 0.3s; touch-action: manipulation;
                `;
                btn.addEventListener('click', () => {
                    selectedChars[index] = trad;
                    btnGroup.querySelectorAll('button').forEach(b => b.style.background = '#f0f8ff');
                    btn.style.background = '#4CAF50';
                    btn.style.color = 'white';
                    
                    // 如果所有字都已選擇，啟用確認按鈕
                    if (!selectedChars.includes(null)) {
                        confirmBtn.disabled = false;
                        confirmBtn.style.background = '#4CAF50';
                    }
                });
                btnGroup.appendChild(btn);
            });
            group.appendChild(btnGroup);
            charGroups.appendChild(group);
        });

        const confirmBtn = document.createElement('button');
        confirmBtn.textContent = '確認';
        confirmBtn.disabled = true;
        confirmBtn.style.cssText = `
            margin-top: 20px; padding: 12px 24px; font-size: 16px; 
            background: #cccccc; color: white; border: none; border-radius: 8px; 
            cursor: not-allowed; transition: all 0.3s; width: 100%; max-width: 200px;
        `;
        confirmBtn.addEventListener('click', () => {
            if (!selectedChars.includes(null)) {
                document.body.removeChild(modal);
                callback(selectedChars);
            }
        });

        container.appendChild(charGroups);
        container.appendChild(confirmBtn);
        modal.appendChild(container);
        document.body.appendChild(modal);

        // 確保觸摸屏友好
        container.querySelectorAll('button').forEach(btn => {
            btn.addEventListener('touchstart', e => {
                e.preventDefault();
                btn.dispatchEvent(new Event('click'));
            });
        });
    }

    // 規範化輸入，處理簡繁轉換
    function normalizeInput(input) {
        if (!input || typeof input !== 'string') return '';
        const chars = input.split('');
        const result = [];
        const multiTradChars = [];

        chars.forEach((char, index) => {
            if (mappings[char] && Array.isArray(mappings[char])) {
                if (mappings[char].length > 1) {
                    multiTradChars.push({ index, char, trads: mappings[char] });
                    result.push(null); // 佔位
                } else {
                    result.push(mappings[char][0]);
                }
            } else {
                result.push(char);
            }
        });

        return new Promise(resolve => {
            if (multiTradChars.length === 0) {
                resolve(result.join(''));
            } else {
                showTradSelection(multiTradChars, selected => {
                    selected.forEach((trad, i) => {
                        result[multiTradChars[i].index] = trad;
                    });
                    resolve(result.join(''));
                });
            }
        });
    }

    // 查詢單字
    function searchWords() {
        const input = wordInput.value.trim();
        if (!input) {
            errorMsg.textContent = '請輸入1-10個漢字';
            errorMsg.style.opacity = 1;
            return;
        }
        if (!/^[^\u0000-\u007F]{1,10}$/.test(input)) {
            errorMsg.textContent = '請輸入1-10個有效漢字';
            errorMsg.style.opacity = 1;
            return;
        }

        loader.style.display = 'block';
        errorMsg.style.opacity = 0;
        strokeResults.innerHTML = '';
        numberResults.innerHTML = '';
        wordNav.innerHTML = '';
        result.innerHTML = '';

        normalizeInput(input).then(normalized => {
            const chars = normalized.split('');
            const promises = chars.map(char => {
                const hex = char.codePointAt(0).toString(16).toUpperCase();
                return fetch(`xyzichars/xyzi_char_${hex}.html`)
                    .then(res => {
                        if (!res.ok) throw new Error(`無法載入 ${char}`);
                        return res.text();
                    })
                    .then(html => ({ char, html }));
            });

            Promise.allSettled(promises).then(results => {
                loader.style.display = 'none';
                wordNav.innerHTML = '';
                result.innerHTML = '';
                results.forEach((res, i) => {
                    const char = chars[i];
                    const link = document.createElement('a');
                    link.className = 'word-link';
                    link.textContent = char;
                    link.href = '#';
                    link.dataset.char = char;
                    link.addEventListener('click', e => {
                        e.preventDefault();
                        if (res.status === 'fulfilled') {
                            result.innerHTML = res.value.html;
                            enhanceResults();
                        } else {
                            errorMsg.textContent = `無法載入 ${char} 的資料`;
                            errorMsg.style.opacity = 1;
                        }
                    });
                    wordNav.appendChild(link);
                });

                // 自動顯示第一個字的結果
                if (results[0].status === 'fulfilled') {
                    result.innerHTML = results[0].value.html;
                    enhanceResults();
                } else {
                    errorMsg.textContent = `無法載入 ${chars[0]} 的資料`;
                    errorMsg.style.opacity = 1;
                }
            });
        });
    }

    // 增強結果顯示
    function enhanceResults() {
        const wordFields = document.querySelector('.word-fields');
        if (wordFields) {
            const wuxing = wordFields.querySelector('.wuxing-金, .wuxing-木, .wuxing-水, .wuxing-火, .wuxing-土, .wuxing-無');
            if (wuxing) {
                const wuxingClass = wuxing.className.split(' ').find(cls => cls.startsWith('wuxing-')) || 'wuxing-none';
                wuxing.className = `value ${wuxingClass}`;
            }
        }
        const returnBtn = document.querySelector('.return-btn');
        if (returnBtn) {
            returnBtn.addEventListener('click', () => {
                result.innerHTML = '';
                wordNav.innerHTML = '';
                strokeResults.innerHTML = '';
                numberResults.innerHTML = '';
                wordInput.value = '';
                wordInput.focus();
            });
        }
    }

    // 動態設置五行分類顏色
    function applyWuxingColors() {
        // 處理普通筆畫（1-30）
        const wuxingGroups = document.querySelectorAll('.wuxing-group');
        wuxingGroups.forEach(group => {
            const header = group.querySelector('h3');
            if (header) {
                const wuxing = header.textContent.match(/^(金|木|水|火|土|其他)/)?.[0];
                if (wuxing && wuxingColors[wuxing]) {
                    header.style.color = wuxingColors[wuxing];
                    header.style.borderBottom = `2px solid ${wuxingColors[wuxing]}`;
                    console.log(`應用顏色: ${wuxing} -> ${wuxingColors[wuxing]} (標題)`);
                }
            }
            const charItems = group.querySelectorAll('.char-item');
            charItems.forEach(item => {
                const wuxingClass = Array.from(item.classList).find(cls => cls.startsWith('wuxing-'));
                if (wuxingClass) {
                    const wuxing = wuxingClass.replace('wuxing-', '');
                    const color = wuxingColors[wuxing] || wuxingColors['其他'];
                    item.style.border = `2px solid ${color}`;
                    item.style.backgroundColor = `${color}20`; // 透明背景
                    console.log(`應用顏色: ${wuxing} -> ${color} (字符 ${item.textContent})`);
                }
            });
        });

        // 處理 30+ 筆畫（stroke-wuxing-group）
        const strokeWuxingGroups = document.querySelectorAll('.stroke-wuxing-group');
        strokeWuxingGroups.forEach(group => {
            const header = group.querySelector('h3');
            if (header) {
                const wuxing = header.textContent.match(/(金|木|水|火|土|其他)/)?.[0];
                if (wuxing && wuxingColors[wuxing]) {
                    header.style.color = wuxingColors[wuxing];
                    header.style.borderBottom = `2px solid ${wuxingColors[wuxing]}`;
                    console.log(`應用顏色: ${wuxing} -> ${wuxingColors[wuxing]} (30+ 標題)`);
                }
            }
            const charItems = group.querySelectorAll('.char-item');
            charItems.forEach(item => {
                const wuxingClass = Array.from(item.classList).find(cls => cls.startsWith('wuxing-'));
                if (wuxingClass) {
                    const wuxing = wuxingClass.replace('wuxing-', '');
                    const color = wuxingColors[wuxing] || wuxingColors['其他'];
                    item.style.border = `2px solid ${color}`;
                    item.style.backgroundColor = `${color}20`; // 透明背景
                    console.log(`應用顏色: ${wuxing} -> ${color} (30+ 字符 ${item.textContent})`);
                }
            });
        });
    }

    // 按筆畫查詢
    function searchByStroke(stroke) {
        if (!stroke || !/^\d{1,2}(\+)?$/.test(stroke)) {
            errorMsg.textContent = '無效的筆畫數';
            errorMsg.style.opacity = 1;
            return;
        }

        loader.style.display = 'block';
        errorMsg.style.opacity = 0;
        strokeResults.innerHTML = '';
        numberResults.innerHTML = '';
        wordNav.innerHTML = '';
        result.innerHTML = '';

        const isRare = showRareChars.checked;
        const file = isRare ? `xyzistrokes/xyzi_stroke_${stroke}_rare.html` : `xyzistrokes/xyzi_stroke_${stroke}.html`;
        fetch(file)
            .then(res => {
                if (!res.ok) throw new Error(`無法載入筆畫 ${stroke}`);
                return res.text();
            })
            .then(html => {
                loader.style.display = 'none';
                strokeResults.innerHTML = html;
                bindCharSelection();
                applyWuxingColors(); // 動態設置五行顏色
            })
            .catch(err => {
                loader.style.display = 'none';
                errorMsg.textContent = err.message;
                errorMsg.style.opacity = 1;
            });
    }

    // 綁定漢字選擇事件
    function bindCharSelection() {
        const charItems = document.querySelectorAll('.char-item');
        charItems.forEach(item => {
            item.addEventListener('click', () => {
                const char = item.dataset.char;
                if (wordInput.value.length < 10) {
                    wordInput.value += char;
                    wordInput.focus();
                } else {
                    errorMsg.textContent = '最多輸入10個漢字';
                    errorMsg.style.opacity = 1;
                }
            });
        });
    }

    // 初始化筆畫連結
    function initStrokeLinks() {
        for (let i = 1; i <= 30; i++) {
            const link = document.createElement('a');
            link.className = 'stroke-link';
            link.href = '#';
            link.textContent = i;
            strokeLinks.appendChild(link);
        }
        const link = document.createElement('a');
        link.className = 'stroke-link';
        link.href = '#';
        link.textContent = '30+';
        strokeLinks.appendChild(link);
    }

    // 初始化
    function init() {
        initStrokeLinks();
        loadMappings().then(() => {
            searchBtn.addEventListener('click', searchWords);
            wordInput.addEventListener('keypress', e => {
                if (e.key === 'Enter') searchWords();
            });
            strokeLinks.addEventListener('click', (e) => {
                if (e.target.classList.contains('stroke-link')) {
                    e.preventDefault();
                    searchByStroke(e.target.textContent);
                }
            });
            showRareChars.addEventListener('change', () => {
                if (strokeResults.innerHTML) {
                    const lastStroke = strokeResults.querySelector('.stroke-count')?.textContent.match(/\d{1,2}(\+)?/)[0];
                    if (lastStroke) {
                        searchByStroke(lastStroke);
                    }
                }
            });
            console.log('漢字查詢系統初始化完成');
        });
    }

    document.addEventListener('DOMContentLoaded', init);
})();